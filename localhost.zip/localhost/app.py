from flask import Flask, render_template, Response, redirect, url_for
import cv2
import numpy as np
from ultralytics import YOLO
import time

app = Flask(__name__)

# Load YOLO model
model = YOLO("yolov8l_bdd10k.onnx", task='detect')

def detect_objects(image):
    """Runs YOLO object detection on the given image."""
    results = model(image)
    return results

def draw_boxes(image, results):
    """Draws bounding boxes on the image."""
    for result in results:
        for i, box in enumerate(result.boxes.xyxy):
            x1, y1, x2, y2 = map(int, box[:4])
            class_id = int(result.boxes.cls[i])
            label = result.names[class_id] if class_id in result.names else "Unknown"
            conf = result.boxes.conf[i]
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 2)
            cv2.putText(image, f"{label} {conf:.2f}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    return image

@app.route('/')
def root():
    return redirect(url_for('live_feed_page'))

@app.route('/live_feed')
def live_feed_page():
    """Render the live feed page and pass a timestamp to force image refresh."""
    return render_template('live_feed.html', time=time.time())

def generate_frames():
    """Captures video frames, processes them, and yields as a live stream (mirrored)."""
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')  # Yield empty frame if webcam fails
        return
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame = cv2.flip(frame, 1)  # Mirror horizontally
        results = detect_objects(frame)
        processed_frame = draw_boxes(frame.copy(), results)
        _, buffer = cv2.imencode('.jpg', processed_frame)
        frame_bytes = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    cap.release()

@app.route('/video_feed')
def video_feed():
    """Provides the live video stream."""
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')